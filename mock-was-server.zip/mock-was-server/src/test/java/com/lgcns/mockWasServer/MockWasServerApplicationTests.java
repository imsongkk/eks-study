package com.lgcns.mockWasServer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MockWasServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
