package com.lgcns.mockWasServer.dto;

import lombok.Builder;

@Builder
public record TagResDto(Long id, String name) {
}
