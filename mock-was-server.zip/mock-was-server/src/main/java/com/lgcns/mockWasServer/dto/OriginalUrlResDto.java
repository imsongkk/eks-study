package com.lgcns.mockWasServer.dto;

import lombok.Builder;

@Builder
public record OriginalUrlResDto(String url, String title) {

}
