package com.lgcns.mockWasServer.enums;

public interface BaseCodeEnum {
    String getCode();
    String getDescription();
}
